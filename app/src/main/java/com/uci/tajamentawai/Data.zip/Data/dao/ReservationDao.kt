package com.uci.tajamentawai.Data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.uci.tajamentawai.Data.entity.Reservation
import kotlinx.coroutines.flow.Flow

@Dao
interface ReservationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reservation: Reservation) : Long

    @Update
    suspend fun update(reservation: Reservation) : Int

    @Query("SELECT * FROM reservation_table")
    fun getAllReservations(): Flow<List<Reservation>>

    @Query("DELETE FROM reservation_table WHERE id = :id ")
    suspend fun deleteAll(id : Int)
}